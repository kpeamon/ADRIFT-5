README FOR COMBINED LIBRARY RELEASE 4.0:
****************************************

The library can be applied in two ways:
1. Either use the Combined Library taf-file as a starting point for your new game
2. Or add the Combined Library amf-file as a selectable library under Settings->Libraries

IMPORTANT:
If you haven't much experience with switching libraries in ADRIFT but decide to do it anyway, there is a risk that you may overwrite the library in an older taf-file with a newer library. More often than not, the game will not work as intended if you update the library in an existing game. In a few situations, you might want to do it anyway to add a new functionality, though you probably will have to make several adjustments to fix the problems caused by the update.

If you decide to work with different libraries, it is highly recommended to have ALL(!) libraries deselected at all times, except while you create a new taf-file. Otherwise, the selected library may overwrite some of the library tasks, or introduce new tasks that are not compatible with the tasks in that taf-file. Depending on your settings, ADRIFT may or may not let you know about this. It may even ask you if you want to update library tasks, but if you say no, it may do it anyway!

If you don't want to mess with libraries, I propose you use the taf-file as a starting point everytime you begin a new game. If you have never changed the default selected libraries to newer ones, ADRIFT should never overwrite a library in your game. Still, also in this situation, I recommend to deselect all libraries if you ever changed or deleted a library task, otherwise you may experience duplicate tasks etc.

It is your choice, just beware that switching libraries increase the risk of ruining old taf-files, so be sure to make backups before opening a taf-file.

Anyway, I hope you find this library useful.